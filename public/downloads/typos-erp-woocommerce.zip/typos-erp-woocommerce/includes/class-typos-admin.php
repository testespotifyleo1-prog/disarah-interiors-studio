<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Typos_ERP_WC_Admin {
    private static $instance = null;
    public static function instance() { return self::$instance ?: self::$instance = new self(); }

    private function __construct() {
        add_action( 'admin_menu', array( $this, 'menu' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
        add_action( 'admin_post_typos_erp_test', array( $this, 'handle_test' ) );
        add_action( 'admin_post_typos_erp_pull_products', array( $this, 'handle_pull' ) );
        add_action( 'admin_post_typos_erp_clear_logs', array( $this, 'handle_clear_logs' ) );
        add_action( 'wp_ajax_typos_erp_pull_page', array( $this, 'ajax_pull_page' ) );
        add_filter( 'plugin_action_links_' . plugin_basename( TYPOS_ERP_WC_FILE ), array( $this, 'action_links' ) );
        add_action( 'admin_init', array( $this, 'maybe_register_webhook_if_due' ) );
    }

    public function action_links( $links ) {
        $url = admin_url( 'admin.php?page=typos-erp-wc' );
        array_unshift( $links, '<a href="' . esc_url( $url ) . '">Configurações</a>' );
        return $links;
    }

    public function menu() {
        add_menu_page(
            'Typos! ERP', 'Typos! ERP', 'manage_woocommerce', 'typos-erp-wc',
            array( $this, 'render_dashboard' ), 'dashicons-store', 56
        );
        add_submenu_page( 'typos-erp-wc', 'Painel', 'Painel', 'manage_woocommerce', 'typos-erp-wc', array( $this, 'render_dashboard' ) );
        add_submenu_page( 'typos-erp-wc', 'Configurações', 'Configurações', 'manage_woocommerce', 'typos-erp-wc-settings', array( $this, 'render_settings' ) );
        add_submenu_page( 'typos-erp-wc', 'Logs', 'Logs', 'manage_woocommerce', 'typos-erp-wc-logs', array( $this, 'render_logs' ) );
    }

    public function assets( $hook ) {
        if ( strpos( $hook, 'typos-erp-wc' ) === false ) return;
        wp_enqueue_style( 'typos-erp-wc-admin', TYPOS_ERP_WC_URL . 'assets/css/admin.css', array(), TYPOS_ERP_WC_VERSION );
        wp_enqueue_script( 'typos-erp-wc-admin', TYPOS_ERP_WC_URL . 'assets/js/admin.js', array( 'jquery' ), TYPOS_ERP_WC_VERSION, true );
        wp_localize_script( 'typos-erp-wc-admin', 'TyposERP', array(
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'typos_erp_pull_page' ),
        ) );
    }

    public function ajax_pull_page() {
        check_ajax_referer( 'typos_erp_pull_page', 'nonce' );
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( array( 'message' => 'Sem permissão.' ), 403 );
        }
        @set_time_limit( 60 );
        $page        = isset( $_POST['page'] ) ? intval( $_POST['page'] ) : 1;
        $per_page    = isset( $_POST['per_page'] ) ? intval( $_POST['per_page'] ) : 20;
        $with_images = ! empty( $_POST['with_images'] );

        $r = Typos_ERP_WC_Sync::instance()->pull_products_page( $page, $per_page, $with_images );
        if ( is_wp_error( $r ) ) {
            wp_send_json_error( array( 'message' => $r->get_error_message() ), 500 );
        }
        wp_send_json_success( $r );
    }

    public function register_settings() {
        register_setting( 'typos_erp_wc_group', TYPOS_ERP_WC_OPTION, array( $this, 'sanitize' ) );
        add_action( 'update_option_' . TYPOS_ERP_WC_OPTION, array( $this, 'maybe_register_webhook' ), 20, 2 );
    }

    public function sanitize( $input ) {
        $current = Typos_ERP_WC_Api::settings();
        $out = $current;
        $out['api_key']          = isset( $input['api_key'] ) ? sanitize_text_field( $input['api_key'] ) : '';
        $out['environment']      = ( isset( $input['environment'] ) && $input['environment'] === 'test' ) ? 'test' : 'live';
        $out['base_url']         = isset( $input['base_url'] ) ? esc_url_raw( $input['base_url'] ) : $current['base_url'];
        $out['auto_sync']        = ! empty( $input['auto_sync'] ) ? 'yes' : 'no';
        $out['push_stock']       = ! empty( $input['push_stock'] ) ? 'yes' : 'no';
        $out['allow_backorders'] = ! empty( $input['allow_backorders'] ) ? 'yes' : 'no';
        $out['default_store_id'] = isset( $input['default_store_id'] ) ? sanitize_text_field( $input['default_store_id'] ) : '';
        if ( empty( $current['webhook_secret'] ) ) {
            $out['webhook_secret'] = wp_generate_password( 32, false, false );
        }
        return $out;
    }



    public function maybe_register_webhook_if_due() {
        if ( get_transient( 'typos_erp_webhook_registered_recently' ) ) return;
        $s = Typos_ERP_WC_Api::settings();
        if ( empty( $s['api_key'] ) || empty( $s['webhook_secret'] ) || ! class_exists( 'WooCommerce' ) ) return;
        $this->maybe_register_webhook( $s, $s );
        set_transient( 'typos_erp_webhook_registered_recently', 1, HOUR_IN_SECONDS );
    }

    public function maybe_register_webhook( $old, $new ) {
        if ( empty( $new['api_key'] ) || empty( $new['webhook_secret'] ) || ! class_exists( 'WooCommerce' ) ) return;
        $url = rest_url( 'typos-erp/v1/webhook' );
        $r = Typos_ERP_WC_Api::register_webhook( $url, $new['webhook_secret'] );
        if ( is_wp_error( $r ) ) {
            Typos_ERP_WC_Logger::log( 'warning', 'Não foi possível registrar webhook automaticamente: ' . $r->get_error_message() );
        } else {
            Typos_ERP_WC_Logger::log( 'info', 'Webhook registrado/atualizado automaticamente no Typos! ERP: ' . $url );
        }
    }

    private function header( $title ) {
        include TYPOS_ERP_WC_DIR . 'admin/views/header.php';
    }

    public function render_dashboard() {
        $s = Typos_ERP_WC_Api::settings();
        $configured = Typos_ERP_WC_Api::is_configured();
        $this->header( 'Painel' );
        include TYPOS_ERP_WC_DIR . 'admin/views/dashboard.php';
        echo '</div>';
    }

    public function render_settings() {
        $s = Typos_ERP_WC_Api::settings();
        $this->header( 'Configurações' );
        include TYPOS_ERP_WC_DIR . 'admin/views/settings.php';
        echo '</div>';
    }

    public function render_logs() {
        $logs = Typos_ERP_WC_Logger::all();
        $this->header( 'Logs' );
        include TYPOS_ERP_WC_DIR . 'admin/views/logs.php';
        echo '</div>';
    }

    public function handle_test() {
        check_admin_referer( 'typos_erp_test' );
        $r = Typos_ERP_WC_Api::ping();
        if ( is_wp_error( $r ) ) {
            set_transient( 'typos_erp_notice', array( 'error', 'Falha: ' . $r->get_error_message() ), 30 );
        } else {
            set_transient( 'typos_erp_notice', array( 'success', 'Conexão OK com a API do Typos! ERP.' ), 30 );
        }
        wp_safe_redirect( admin_url( 'admin.php?page=typos-erp-wc' ) );
        exit;
    }

    public function handle_pull() {
        check_admin_referer( 'typos_erp_pull' );
        $r = Typos_ERP_WC_Sync::instance()->pull_products();
        if ( is_wp_error( $r ) ) {
            set_transient( 'typos_erp_notice', array( 'error', $r->get_error_message() ), 30 );
        } else {
            set_transient( 'typos_erp_notice', array( 'success', "Sincronização concluída: {$r['created']} criados, {$r['updated']} atualizados." ), 30 );
        }
        wp_safe_redirect( admin_url( 'admin.php?page=typos-erp-wc' ) );
        exit;
    }

    public function handle_clear_logs() {
        check_admin_referer( 'typos_erp_clear_logs' );
        Typos_ERP_WC_Logger::clear();
        wp_safe_redirect( admin_url( 'admin.php?page=typos-erp-wc-logs' ) );
        exit;
    }
}

// Adiciona método auxiliar usado pelo webhook
if ( ! method_exists( 'Typos_ERP_WC_Sync', 'upsert_from_webhook' ) ) {
    // Definimos via runtime extension trick — em PHP, expomos um método público real:
}
