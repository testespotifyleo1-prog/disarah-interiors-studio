<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Garante de forma DEFINITIVA que produtos sem estoque no Typos! ERP
 * não possam ser vendidos pelo WooCommerce quando "Permitir backorder"
 * estiver desativado.
 *
 * Estratégia (à prova de oversell):
 *  - Usa o meta `_typos_product_id` como fonte da verdade. Se o produto
 *    foi sincronizado, ele é controlado pelo ERP, independentemente do
 *    "Manage stock" do WooCommerce.
 *  - Em listagens (is_in_stock / is_purchasable) usa o `stock_quantity`
 *    persistido + cache curto (5s) do estoque ao vivo.
 *  - Em qualquer ponto do funil de compra (add to cart, view cart,
 *    checkout) consulta o ERP em tempo real via /v1/stock?product_id=...
 *    e bloqueia se a quantidade for insuficiente.
 *  - Quando bloqueia, atualiza imediatamente o produto no WooCommerce
 *    para `outofstock` para refletir o estado real.
 */
class Typos_ERP_WC_Stock_Guard {
    const CACHE_PREFIX = 'typos_qty_';
    const CACHE_TTL    = 5; // segundos

    private static $instance = null;
    public static function instance() { return self::$instance ?: self::$instance = new self(); }

    private function __construct() {
        add_filter( 'woocommerce_product_backorders_allowed',              array( $this, 'force_backorders' ), 99, 3 );
        add_filter( 'woocommerce_product_backorders_require_notification', array( $this, 'force_backorders' ), 99, 3 );

        add_filter( 'woocommerce_product_is_in_stock',      array( $this, 'force_in_stock' ), 99, 2 );
        add_filter( 'woocommerce_variation_is_in_stock',    array( $this, 'force_in_stock' ), 99, 2 );
        add_filter( 'woocommerce_product_is_purchasable',   array( $this, 'force_purchasable' ), 99, 2 );
        add_filter( 'woocommerce_variation_is_purchasable', array( $this, 'force_purchasable' ), 99, 2 );
        add_filter( 'woocommerce_get_availability_text',    array( $this, 'force_availability_text' ), 99, 2 );

        add_filter( 'woocommerce_add_to_cart_validation',   array( $this, 'validate_add_to_cart' ), 10, 5 );
        add_action( 'woocommerce_check_cart_items',         array( $this, 'validate_cart' ) );
        add_action( 'woocommerce_after_checkout_validation',array( $this, 'validate_checkout' ), 10, 2 );

        add_action( 'update_option_' . TYPOS_ERP_WC_OPTION, array( $this, 'on_settings_saved' ), 10, 2 );
    }

    private function backorders_allowed() {
        $s = Typos_ERP_WC_Api::settings();
        return ( ( $s['allow_backorders'] ?? 'no' ) === 'yes' );
    }

    /**
     * Retorna o id do produto no Typos! ERP, se houver.
     */
    private function typos_id( $product ) {
        if ( ! $product instanceof WC_Product ) return '';
        $id = $product->get_meta( '_typos_product_id' );
        return is_string( $id ) ? trim( $id ) : '';
    }

    /**
     * Estoque ao vivo somando todas as lojas. Usa cache curto.
     * Retorna null se não foi possível consultar (mantém comportamento padrão).
     */
    private function live_qty( $typos_product_id ) {
        if ( empty( $typos_product_id ) ) return null;
        $key = self::CACHE_PREFIX . md5( $typos_product_id );
        $cached = get_transient( $key );
        if ( $cached !== false ) return (float) $cached;

        if ( ! Typos_ERP_WC_Api::is_configured() ) return null;
        $s = Typos_ERP_WC_Api::settings();
        $filters = array( 'product_id' => $typos_product_id );
        if ( ! empty( $s['default_store_id'] ) ) {
            $filters['store_id'] = $s['default_store_id'];
        }
        $res = Typos_ERP_WC_Api::list_stock( 1, 100, $filters );
        if ( is_wp_error( $res ) ) return null;

        $rows = isset( $res['data'] ) ? $res['data'] : array();
        $total = 0.0;
        foreach ( $rows as $r ) {
            $total += (float) ( $r['qty_on_hand'] ?? 0 );
        }
        set_transient( $key, $total, self::CACHE_TTL );
        return $total;
    }

    /**
     * Persiste o status correto no WC (manage_stock=on, qty, status).
     */
    private function apply_stock_to_product( $product, $qty ) {
        if ( ! $product instanceof WC_Product ) return;
        $qty = (float) $qty;
        $allow = $this->backorders_allowed();
        $status = ( $qty > 0 || $allow ) ? 'instock' : 'outofstock';
        $backorders = $allow ? 'yes' : 'no';
        $changed = ! $product->managing_stock()
            || (float) $product->get_stock_quantity() !== $qty
            || $product->get_stock_status() !== $status
            || $product->get_backorders() !== $backorders;
        if ( ! $changed ) return;
        $product->set_manage_stock( true );
        $product->set_stock_quantity( $qty );
        $product->set_backorders( $backorders );
        $product->set_stock_status( $status );
        $product->save();
        if ( function_exists( 'wc_delete_product_transients' ) ) {
            wc_delete_product_transients( $product->get_id() );
        }
        clean_post_cache( $product->get_id() );
    }

    public function force_backorders( $value, $product_id = 0, $product = null ) {
        return $this->backorders_allowed() ? $value : 'no';
    }

    private function live_qty_for_product( $product ) {
        $tid = $this->typos_id( $product );
        if ( empty( $tid ) ) return null;
        $live = $this->live_qty( $tid );
        if ( $live !== null ) {
            $this->apply_stock_to_product( $product, $live );
            return (float) $live;
        }
        return (float) $product->get_stock_quantity();
    }

    public function force_in_stock( $in_stock, $product ) {
        if ( $this->backorders_allowed() ) return $in_stock;
        if ( empty( $this->typos_id( $product ) ) ) return $in_stock;

        // Consulta o ERP também quando o WC está zerado; assim o produto volta
        // para "em estoque" logo que o saldo for reposto no ERP.
        $qty = $this->live_qty_for_product( $product );
        if ( $qty === null ) return $in_stock;
        return $qty > 0;
    }

    public function force_purchasable( $purchasable, $product ) {
        if ( $this->backorders_allowed() ) return $purchasable;
        if ( empty( $this->typos_id( $product ) ) ) return $purchasable;

        $qty = $this->live_qty_for_product( $product );
        if ( $qty === null ) return $purchasable;
        return $qty > 0 ? $purchasable : false;
    }

    public function force_availability_text( $text, $product ) {
        if ( $this->backorders_allowed() ) return $text;
        if ( empty( $this->typos_id( $product ) ) ) return $text;

        $qty = $this->live_qty_for_product( $product );
        if ( $qty !== null && $qty <= 0 ) return __( 'Fora de estoque', 'typos-erp-wc' );
        if ( $qty !== null && $qty > 0 ) return __( 'Em estoque', 'typos-erp-wc' );
        return $text;
    }

    public function validate_add_to_cart( $passed, $product_id, $quantity, $variation_id = 0, $variations = array() ) {
        if ( $this->backorders_allowed() ) return $passed;
        $product = $variation_id ? wc_get_product( $variation_id ) : wc_get_product( $product_id );
        $tid = $this->typos_id( $product );
        if ( empty( $tid ) ) return $passed;

        $live = $this->live_qty( $tid );
        $qty  = $live !== null ? $live : (float) $product->get_stock_quantity();

        if ( $live !== null ) {
            $this->apply_stock_to_product( $product, $live );
        }

        if ( $qty < (float) $quantity ) {
            wc_add_notice(
                sprintf( __( 'Desculpe, "%1$s" está sem estoque suficiente (disponível: %2$s).', 'typos-erp-wc' ),
                    $product->get_name(), max( 0, $qty ) ),
                'error'
            );
            return false;
        }
        return $passed;
    }

    public function validate_cart() {
        if ( $this->backorders_allowed() ) return;
        if ( ! WC()->cart ) return;
        foreach ( WC()->cart->get_cart() as $item ) {
            $product = $item['data'] ?? null;
            $tid = $this->typos_id( $product );
            if ( empty( $tid ) ) continue;

            $live = $this->live_qty( $tid );
            $qty  = $live !== null ? $live : (float) $product->get_stock_quantity();
            if ( $live !== null ) $this->apply_stock_to_product( $product, $live );

            if ( $qty < (float) $item['quantity'] ) {
                wc_add_notice(
                    sprintf( __( 'Produto "%1$s" está sem estoque (disponível: %2$s). Remova-o do carrinho para continuar.', 'typos-erp-wc' ),
                        $product->get_name(), max( 0, $qty ) ),
                    'error'
                );
            }
        }
    }

    public function validate_checkout( $data, $errors ) {
        if ( $this->backorders_allowed() ) return;
        if ( ! WC()->cart ) return;
        foreach ( WC()->cart->get_cart() as $item ) {
            $product = $item['data'] ?? null;
            $tid = $this->typos_id( $product );
            if ( empty( $tid ) ) continue;

            $live = $this->live_qty( $tid );
            $qty  = $live !== null ? $live : (float) $product->get_stock_quantity();
            if ( $live !== null ) $this->apply_stock_to_product( $product, $live );

            if ( $qty < (float) $item['quantity'] ) {
                $errors->add( 'out_of_stock',
                    sprintf( __( 'Produto "%s" está sem estoque suficiente.', 'typos-erp-wc' ), $product->get_name() )
                );
            }
        }
    }

    /**
     * Quando o admin troca "permitir backorder", reaplica em todos os produtos
     * sincronizados do Typos.
     */
    public function on_settings_saved( $old, $new ) {
        $old_v = $old['allow_backorders'] ?? 'no';
        $new_v = $new['allow_backorders'] ?? 'no';
        if ( $old_v === $new_v ) return;
        $allow = ( $new_v === 'yes' );

        $paged = 1;
        do {
            $q = new WP_Query( array(
                'post_type'      => array( 'product', 'product_variation' ),
                'post_status'    => 'any',
                'fields'         => 'ids',
                'posts_per_page' => 100,
                'paged'          => $paged,
                'no_found_rows'  => false,
                'meta_query'     => array(
                    array( 'key' => '_typos_product_id', 'compare' => 'EXISTS' ),
                ),
            ) );
            if ( empty( $q->posts ) ) break;
            foreach ( $q->posts as $pid ) {
                $product = wc_get_product( $pid );
                if ( ! $product ) continue;
                $product->set_manage_stock( true );
                $product->set_backorders( $allow ? 'yes' : 'no' );
                $qty = (float) $product->get_stock_quantity();
                $product->set_stock_status( ( $qty > 0 || $allow ) ? 'instock' : 'outofstock' );
                $product->save();
            }
            $paged++;
        } while ( $paged <= $q->max_num_pages );

        Typos_ERP_WC_Logger::log( 'info', 'Backorder global redefinido para ' . ( $allow ? 'permitido' : 'bloqueado' ) . ' — produtos atualizados.' );
    }
}
