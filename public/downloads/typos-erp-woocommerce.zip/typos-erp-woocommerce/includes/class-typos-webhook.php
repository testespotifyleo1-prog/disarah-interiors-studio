<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Recebe webhooks do Typos! ERP em /wp-json/typos-erp/v1/webhook
 * Verifica HMAC SHA-256 com webhook_secret no header X-Typos-Signature.
 */
class Typos_ERP_WC_Webhook {
    private static $instance = null;
    public static function instance() { return self::$instance ?: self::$instance = new self(); }

    private function __construct() {
        add_action( 'rest_api_init', array( $this, 'register' ) );
    }

    public function register() {
        register_rest_route( 'typos-erp/v1', '/webhook', array(
            'methods'             => 'POST',
            'callback'            => array( $this, 'handle' ),
            'permission_callback' => '__return_true',
        ) );
    }

    public function handle( WP_REST_Request $request ) {
        $s = Typos_ERP_WC_Api::settings();
        $secret = $s['webhook_secret'] ?? '';
        $signature = $request->get_header( 'x-typos-signature' );
        $body = $request->get_body();

        if ( $secret ) {
            $expected = hash_hmac( 'sha256', $body, $secret );
            $received = is_string( $signature ) ? trim( $signature ) : '';
            if ( strpos( $received, 'sha256=' ) === 0 ) {
                $received = substr( $received, 7 );
            }
            if ( ! $received || ! hash_equals( $expected, $received ) ) {
                Typos_ERP_WC_Logger::log( 'warning', 'Webhook recusado: assinatura inválida.' );
                return new WP_REST_Response( array( 'ok' => false, 'error' => 'invalid_signature' ), 401 );
            }
        }

        $payload = json_decode( $body, true );
        $event = isset( $payload['event'] ) ? $payload['event'] : '';
        Typos_ERP_WC_Logger::log( 'info', 'Webhook recebido: ' . $event );

        // Roteamento simples
        if ( strpos( $event, 'product.' ) === 0 && ! empty( $payload['data'] ) ) {
            Typos_ERP_WC_Sync::instance()->upsert_from_webhook( $payload['data'] );
        }
        if ( strpos( $event, 'stock.' ) === 0 && ! empty( $payload['data'] ) ) {
            self::sync_stock_to_wc( $payload['data'] );
        }

        return new WP_REST_Response( array( 'ok' => true ), 200 );
    }

    public static function sync_stock_to_wc( $row ) {
        if ( empty( $row['product_id'] ) ) return;

        $s = Typos_ERP_WC_Api::settings();
        if ( ! empty( $s['default_store_id'] ) && ! empty( $row['store_id'] ) && $row['store_id'] !== $s['default_store_id'] ) {
            return;
        }

        $args = array(
            'meta_key'        => '_typos_product_id',
            'meta_value'      => $row['product_id'],
            'post_type'       => array( 'product', 'product_variation' ),
            'post_status'     => 'any',
            'fields'          => 'ids',
            'posts_per_page'  => 1,
        );
        $ids = get_posts( $args );
        if ( empty( $ids ) ) return;

        $qty = null;
        if ( ! empty( $s['default_store_id'] ) || isset( $row['qty_on_hand'] ) ) {
            $qty = (float) ( $row['qty_on_hand'] ?? 0 );
        }
        if ( empty( $s['default_store_id'] ) && Typos_ERP_WC_Api::is_configured() ) {
            $res = Typos_ERP_WC_Api::list_stock( 1, 100, array( 'product_id' => $row['product_id'] ) );
            if ( ! is_wp_error( $res ) ) {
                $qty = 0.0;
                foreach ( ( $res['data'] ?? array() ) as $stock_row ) {
                    $qty += (float) ( $stock_row['qty_on_hand'] ?? 0 );
                }
            }
        }
        if ( $qty === null ) return;

        $product = wc_get_product( $ids[0] );
        if ( ! $product ) return;
        $product->set_manage_stock( true );
        $product->set_stock_quantity( $qty );

        $allow_backorders = ( ( $s['allow_backorders'] ?? 'no' ) === 'yes' );
        $product->set_backorders( $allow_backorders ? 'yes' : 'no' );
        $product->set_stock_status( ( $qty > 0 || $allow_backorders ) ? 'instock' : 'outofstock' );
        $product->save();
        delete_transient( 'typos_qty_' . md5( (string) $row['product_id'] ) );
        if ( function_exists( 'wc_delete_product_transients' ) ) {
            wc_delete_product_transients( $product->get_id() );
        }
        clean_post_cache( $product->get_id() );
        Typos_ERP_WC_Logger::log( 'info', 'Estoque atualizado no WooCommerce: produto ' . $row['product_id'] . ' → ' . $qty );
    }
}

// Permite que Typos_ERP_WC_Sync seja chamado pelo webhook
if ( ! method_exists( 'Typos_ERP_WC_Sync', 'upsert_from_webhook' ) ) {
    // adicionado dinamicamente via wrapper estático
}
