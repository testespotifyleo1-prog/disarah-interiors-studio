<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Typos_ERP_WC_Logger {
    public static function log( $level, $message, $context = array() ) {
        $logs = get_option( TYPOS_ERP_WC_LOG_OPT, array() );
        if ( ! is_array( $logs ) ) { $logs = array(); }
        $logs[] = array(
            'time'    => current_time( 'mysql' ),
            'level'   => $level,
            'message' => is_string( $message ) ? $message : wp_json_encode( $message ),
            'context' => $context,
        );
        // keep last 200
        if ( count( $logs ) > 200 ) { $logs = array_slice( $logs, -200 ); }
        update_option( TYPOS_ERP_WC_LOG_OPT, $logs, false );
    }
    public static function clear() { update_option( TYPOS_ERP_WC_LOG_OPT, array(), false ); }
    public static function all() { return array_reverse( (array) get_option( TYPOS_ERP_WC_LOG_OPT, array() ) ); }
}
