<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Cliente HTTP da API pública do Typos! ERP.
 */
class Typos_ERP_WC_Api {

    public static function settings() {
        $defaults = array(
            'api_key'       => '',
            'environment'   => 'live',
            'base_url'      => 'https://ietaxjtvtrfxtrkjvcso.supabase.co/functions/v1/public-api',
            'auto_sync'     => 'no',
            'push_stock'    => 'yes',
            'allow_backorders' => 'no',
            'default_store_id' => '',
            'webhook_secret'=> '',
        );
        return wp_parse_args( get_option( TYPOS_ERP_WC_OPTION, array() ), $defaults );
    }

    public static function is_configured() {
        $s = self::settings();
        return ! empty( $s['api_key'] ) && ! empty( $s['base_url'] );
    }

    public static function request( $method, $path, $body = null, $query = array() ) {
        $s = self::settings();
        if ( empty( $s['api_key'] ) ) {
            return new WP_Error( 'typos_no_key', 'Chave de API do Typos! ERP não configurada.' );
        }
        $url = rtrim( $s['base_url'], '/' ) . '/' . ltrim( $path, '/' );
        if ( ! empty( $query ) ) {
            $url = add_query_arg( array_filter( $query, function( $v ) { return $v !== null && $v !== ''; } ), $url );
        }

        $args = array(
            'method'  => strtoupper( $method ),
            'timeout' => 30,
            'headers' => array(
                'Authorization'         => 'Bearer ' . $s['api_key'],
                'Content-Type'          => 'application/json',
                'Accept'                => 'application/json',
                'X-Typos-Environment'   => $s['environment'] === 'test' ? 'test' : 'live',
                'User-Agent'            => 'Typos-ERP-WC/' . TYPOS_ERP_WC_VERSION . '; ' . home_url( '/' ),
            ),
        );
        if ( ! is_null( $body ) ) {
            $args['body'] = wp_json_encode( $body );
        }

        $res = wp_remote_request( $url, $args );
        if ( is_wp_error( $res ) ) {
            Typos_ERP_WC_Logger::log( 'error', 'HTTP error: ' . $res->get_error_message(), array( 'url' => $url ) );
            return $res;
        }
        $code = wp_remote_retrieve_response_code( $res );
        $raw  = wp_remote_retrieve_body( $res );
        $data = json_decode( $raw, true );

        if ( $code >= 400 ) {
            $msg = isset( $data['error']['message'] ) ? $data['error']['message'] : ( 'HTTP ' . $code );
            Typos_ERP_WC_Logger::log( 'error', $method . ' ' . $path . ' → ' . $msg, array( 'status' => $code, 'body' => $data ) );
            return new WP_Error( 'typos_api_' . $code, $msg, $data );
        }
        return $data;
    }

    public static function ping() {
        return self::request( 'GET', '/' );
    }

    public static function list_products( $page = 1, $limit = 50, $extra = array() ) {
        return self::request( 'GET', '/v1/products', null, array_merge( array( 'page' => $page, 'limit' => $limit ), $extra ) );
    }

    public static function list_stock( $page = 1, $limit = 100, $extra = array() ) {
        return self::request( 'GET', '/v1/stock', null, array_merge( array( 'page' => $page, 'limit' => $limit ), $extra ) );
    }

    public static function adjust_stock( $store_id, $product_id, $qty_delta = null, $qty_on_hand = null, $min_qty = null ) {
        $body = array( 'store_id' => $store_id, 'product_id' => $product_id );
        if ( ! is_null( $qty_delta ) )   { $body['qty_delta'] = $qty_delta; }
        if ( ! is_null( $qty_on_hand ) ) { $body['qty_on_hand'] = $qty_on_hand; }
        if ( ! is_null( $min_qty ) )     { $body['min_qty'] = $min_qty; }
        return self::request( 'POST', '/v1/stock/adjust', $body );
    }

    public static function list_stores() {
        return self::request( 'GET', '/v1/stores' );
    }

    public static function upsert_customer( $payload ) {
        return self::request( 'POST', '/v1/customers', $payload );
    }
    public static function create_sale( $payload ) {
        return self::request( 'POST', '/v1/sales', $payload );
    }
    public static function cancel_sale( $payload ) {
        return self::request( 'POST', '/v1/sales/cancel', $payload );
    }
    public static function update_sale_status( $payload ) {
        return self::request( 'POST', '/v1/sales/status', $payload );
    }

    public static function register_webhook( $url, $secret ) {
        return self::request( 'POST', '/v1/webhooks/register', array(
            'url'    => $url,
            'secret' => $secret,
            'events' => array( 'stock.changed', 'product.updated', 'sale.paid' ),
        ) );
    }

}

