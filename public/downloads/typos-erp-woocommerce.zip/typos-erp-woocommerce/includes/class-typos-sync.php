<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Typos_ERP_WC_Sync {
    private static $instance = null;
    public static function instance() { return self::$instance ?: self::$instance = new self(); }

    private function __construct() {
        add_action( 'woocommerce_order_status_changed', array( $this, 'on_order_status_changed' ), 20, 4 );

        add_action( 'typos_erp_wc_daily_sync', array( $this, 'pull_products_full' ) );
        if ( ! wp_next_scheduled( 'typos_erp_wc_daily_sync' ) ) {
            wp_schedule_event( time() + 3600, 'daily', 'typos_erp_wc_daily_sync' );
        }
    }

    public function pull_products_full() {
        if ( ! Typos_ERP_WC_Api::is_configured() ) return;
        @set_time_limit( 0 );
        $page = 1; $created = 0; $updated = 0;
        do {
            $r = $this->pull_products_page( $page, 50, true );
            if ( is_wp_error( $r ) ) break;
            $created += $r['created']; $updated += $r['updated'];
            $page++;
        } while ( ! empty( $r['has_more'] ) && $page < 200 );
        Typos_ERP_WC_Logger::log( 'info', "Cron pull: {$created} criados, {$updated} atualizados." );
    }

    public function pull_products_page( $page = 1, $per_page = 20, $with_images = false ) {
        if ( ! Typos_ERP_WC_Api::is_configured() ) {
            return new WP_Error( 'not_configured', 'Configure a chave de API.' );
        }
        $page     = max( 1, intval( $page ) );
        $per_page = max( 1, min( 100, intval( $per_page ) ) );

        $res = Typos_ERP_WC_Api::list_products( $page, $per_page );
        if ( is_wp_error( $res ) ) return $res;

        $items = isset( $res['data'] ) ? $res['data'] : array();
        $total       = isset( $res['pagination']['total'] ) ? intval( $res['pagination']['total'] ) : 0;
        $total_pages = isset( $res['pagination']['total_pages'] ) ? intval( $res['pagination']['total_pages'] ) : 0;
        if ( ! $total_pages && $total && $per_page ) {
            $total_pages = (int) ceil( $total / $per_page );
        }

        $created = 0; $updated = 0; $skipped = 0;
        foreach ( $items as $p ) {
            $r = $this->upsert_wc_product( $p, $with_images );
            if ( $r === 'created' )      $created++;
            elseif ( $r === 'updated' )  $updated++;
            else                          $skipped++;
        }

        return array(
            'page'        => $page,
            'per_page'    => $per_page,
            'processed'   => count( $items ),
            'created'     => $created,
            'updated'     => $updated,
            'skipped'     => $skipped,
            'total'       => $total,
            'total_pages' => $total_pages,
            'has_more'    => $page < $total_pages,
        );
    }

    public function upsert_from_webhook( $p ) { return $this->upsert_wc_product( $p, true ); }

    private function upsert_wc_product( $p, $with_images = false ) {
        if ( empty( $p['sku'] ) && empty( $p['gtin'] ) && empty( $p['id'] ) ) return null;
        $sku = ! empty( $p['sku'] ) ? $p['sku'] : ( ! empty( $p['gtin'] ) ? $p['gtin'] : 'TYP-' . $p['id'] );

        $product_id = wc_get_product_id_by_sku( $sku );
        $product = $product_id ? wc_get_product( $product_id ) : new WC_Product_Simple();
        $is_new = ! $product_id;

        $product->set_sku( $sku );
        if ( ! empty( $p['name'] ) )              $product->set_name( $p['name'] );
        if ( isset( $p['description_long'] ) )    $product->set_description( (string) $p['description_long'] );
        if ( isset( $p['description'] ) )         $product->set_short_description( (string) $p['description'] );
        if ( isset( $p['price_default'] ) )       $product->set_regular_price( (string) $p['price_default'] );
        if ( ! empty( $p['promo_price'] ) )       $product->set_sale_price( (string) $p['promo_price'] );
        if ( isset( $p['weight'] ) )              $product->set_weight( (string) $p['weight'] );
        if ( isset( $p['is_active'] ) )           $product->set_status( $p['is_active'] ? 'publish' : 'draft' );

        $product->update_meta_data( '_typos_product_id', isset( $p['id'] ) ? $p['id'] : '' );
        $product->update_meta_data( '_typos_gtin', isset( $p['gtin'] ) ? $p['gtin'] : '' );

        // Backorder / stock status conforme configuração global do plugin
        $s_cfg = Typos_ERP_WC_Api::settings();
        $allow_backorders = ( ( $s_cfg['allow_backorders'] ?? 'no' ) === 'yes' );
        if ( isset( $p['qty_on_hand'] ) ) {
            $product->set_manage_stock( true );
            $product->set_stock_quantity( (float) $p['qty_on_hand'] );
        }
        $product->set_backorders( $allow_backorders ? 'yes' : 'no' );
        $current_qty = (float) $product->get_stock_quantity();
        $product->set_stock_status( ( $current_qty > 0 || $allow_backorders ) ? 'instock' : 'outofstock' );

        $id = $product->save();

        if ( $with_images && $is_new && ! empty( $p['image_url'] ) ) {
            $this->maybe_attach_image( $id, $p['image_url'] );
        }
        return $is_new ? 'created' : 'updated';
    }

    private function maybe_attach_image( $product_id, $url ) {
        if ( ! function_exists( 'media_sideload_image' ) ) {
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }
        $att = media_sideload_image( $url, $product_id, null, 'id' );
        if ( ! is_wp_error( $att ) ) {
            set_post_thumbnail( $product_id, $att );
        }
    }

    /**
     * Mapeia método de pagamento do WooCommerce → enum do ERP.
     */
    private function map_payment_method( $wc_method ) {
        $m = strtolower( (string) $wc_method );
        if ( strpos( $m, 'pix' ) !== false )                                return 'pix';
        if ( strpos( $m, 'cod' ) !== false || strpos( $m, 'cash' ) !== false || strpos( $m, 'dinheiro' ) !== false ) return 'cash';
        if ( strpos( $m, 'card' ) !== false || strpos( $m, 'cartao' ) !== false || strpos( $m, 'cartão' ) !== false
             || strpos( $m, 'stripe' ) !== false || strpos( $m, 'mercadopago' ) !== false || strpos( $m, 'pagseguro' ) !== false
             || strpos( $m, 'cielo' ) !== false || strpos( $m, 'rede' ) !== false ) return 'card';
        if ( strpos( $m, 'bacs' ) !== false || strpos( $m, 'transfer' ) !== false ) return 'pix';
        return 'card';
    }

    private function map_order_status( $wc_status ) {
        $s = strtolower( (string) $wc_status );
        if ( in_array( $s, array( 'processing', 'completed' ), true ) ) return 'paid';
        if ( in_array( $s, array( 'cancelled', 'refunded', 'failed' ), true ) ) return 'canceled';
        if ( in_array( $s, array( 'pending', 'on-hold', 'checkout-draft' ), true ) ) return 'open';
        return 'open';
    }

    private function is_paid_erp_status( $erp_status ) {
        return in_array( $erp_status, array( 'paid', 'crediario' ), true );
    }

    private function build_order_payload( $order, $erp_status ) {
        $s = Typos_ERP_WC_Api::settings();
        $order_id = $order->get_id();

        $items = array();
        foreach ( $order->get_items() as $item ) {
            $prod = $item->get_product();
            if ( ! $prod ) continue;
            $typos_id = $prod->get_meta( '_typos_product_id' );
            $sku      = $prod->get_sku();
            $qty      = (float) $item->get_quantity();
            if ( $qty <= 0 ) continue;

            $line = array(
                'qty'        => $qty,
                'unit_price' => $qty > 0 ? round( ( (float) $item->get_total() + (float) $item->get_total_tax() ) / $qty, 2 ) : 0,
            );
            if ( ! empty( $typos_id ) ) $line['product_id'] = $typos_id;
            elseif ( ! empty( $sku ) )  $line['sku']        = $sku;
            else continue;

            $items[] = $line;
        }

        $address = array(
            'street'       => $order->get_billing_address_1(),
            'number'       => '',
            'complement'   => $order->get_billing_address_2(),
            'neighborhood' => '',
            'city'         => $order->get_billing_city(),
            'state'        => $order->get_billing_state(),
            'zip'          => $order->get_billing_postcode(),
            'country'      => $order->get_billing_country(),
        );
        $customer = array(
            'name'         => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) ?: $order->get_formatted_billing_full_name(),
            'email'        => $order->get_billing_email(),
            'phone'        => $order->get_billing_phone(),
            'address_json' => $address,
        );

        $payload = array(
            'external_id'  => 'WC-' . $order_id,
            'source'       => 'woocommerce',
            'status'       => $erp_status,
            'subtotal'     => (float) $order->get_subtotal(),
            'discount'     => (float) $order->get_total_discount(),
            'delivery_fee' => (float) $order->get_shipping_total(),
            'total'        => (float) $order->get_total(),
            'customer'     => $customer,
            'items'        => $items,
            'payments'     => array(),
            'notes'        => "Pedido WooCommerce #{$order_id} — Status: " . $order->get_status() . ' — ' . $order->get_payment_method_title(),
        );

        if ( $this->is_paid_erp_status( $erp_status ) ) {
            $payload['payments'][] = array(
                'method'     => $this->map_payment_method( $order->get_payment_method() ),
                'paid_value' => (float) $order->get_total(),
                'notes'      => $order->get_payment_method_title(),
            );
        }

        if ( ! empty( $s['default_store_id'] ) ) {
            $payload['store_id'] = $s['default_store_id'];
        }

        return $payload;
    }

    public function on_order_status_changed( $order_id, $old_status = '', $new_status = '', $order = null ) {
        $this->sync_order_to_erp( $order_id, $new_status );
    }

    /**
     * Mantido para compatibilidade: qualquer status relevante agora passa pelo mesmo sincronizador.
     */
    public function on_order_paid( $order_id ) {
        $this->sync_order_to_erp( $order_id );
    }

    public function on_order_cancelled( $order_id ) {
        $this->sync_order_to_erp( $order_id, 'cancelled' );
    }

    private function sync_order_to_erp( $order_id, $wc_status = null ) {
        if ( ! Typos_ERP_WC_Api::is_configured() ) return;

        $order = wc_get_order( $order_id );
        if ( ! $order ) return;

        $wc_status  = $wc_status ? $wc_status : $order->get_status();
        $erp_status = $this->map_order_status( $wc_status );

        if ( $erp_status === 'canceled' && $order->get_meta( '_typos_sale_pushed' ) !== 'yes' ) {
            return;
        }

        $payload = $this->build_order_payload( $order, $erp_status );
        if ( empty( $payload['items'] ) ) {
            Typos_ERP_WC_Logger::log( 'warning', "Pedido #{$order_id}: nenhum item válido para enviar ao ERP." );
            return;
        }

        $sale_id = $order->get_meta( '_typos_sale_id' );
        if ( $order->get_meta( '_typos_sale_pushed' ) === 'yes' ) {
            if ( $sale_id ) $payload['sale_id'] = $sale_id;
            $payload['reason'] = 'Status alterado no WooCommerce para ' . $wc_status;
            $r = Typos_ERP_WC_Api::update_sale_status( $payload );
            if ( is_wp_error( $r ) ) {
                Typos_ERP_WC_Logger::log( 'error', "Falha ao atualizar status no ERP (pedido {$order_id}): " . $r->get_error_message() );
                return;
            }
            $order->update_meta_data( '_typos_sale_canceled', $erp_status === 'canceled' ? 'yes' : 'no' );
            $order->save();
            Typos_ERP_WC_Logger::log( 'info', "Pedido #{$order_id}: status WooCommerce {$wc_status} → ERP {$erp_status}." );
            return;
        }

        $r = Typos_ERP_WC_Api::create_sale( $payload );
        if ( is_wp_error( $r ) ) {
            Typos_ERP_WC_Logger::log( 'error', "Falha ao criar venda no ERP (pedido {$order_id}): " . $r->get_error_message() );
            return;
        }

        $sale_id = isset( $r['data']['id'] ) ? $r['data']['id'] : '';
        $order_number = isset( $r['data']['order_number'] ) ? $r['data']['order_number'] : '';
        $order->update_meta_data( '_typos_sale_pushed', 'yes' );
        $order->update_meta_data( '_typos_sale_id', $sale_id );
        $order->update_meta_data( '_typos_sale_canceled', $erp_status === 'canceled' ? 'yes' : 'no' );
        if ( $order_number ) $order->update_meta_data( '_typos_order_number', $order_number );
        $order->save();

        $suffix = $this->is_paid_erp_status( $erp_status ) ? 'estoque baixado automaticamente' : 'aguardando pagamento';
        Typos_ERP_WC_Logger::log( 'info', "Pedido #{$order_id} → ERP venda #{$order_number} ({$erp_status}; {$suffix})." );
    }

}
