<?php
/**
 * Plugin Name: Typos! ERP — WooCommerce
 * Plugin URI:  https://typoserp.com.br/docs/api
 * Description: Integra o Typos! ERP ao WooCommerce — sincroniza produtos, estoque e clientes através da API pública (REST v1).
 * Version:     1.8.0
 * Author:      Typos! ERP
 * Author URI:  https://typoserp.com.br
 * License:     GPL-2.0+
 * Text Domain: typos-erp-wc
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 * WC tested up to: 9.3
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'TYPOS_ERP_WC_VERSION', '1.8.0' );
define( 'TYPOS_ERP_WC_FILE',    __FILE__ );
define( 'TYPOS_ERP_WC_DIR',     plugin_dir_path( __FILE__ ) );
define( 'TYPOS_ERP_WC_URL',     plugin_dir_url( __FILE__ ) );
define( 'TYPOS_ERP_WC_OPTION',  'typos_erp_wc_settings' );
define( 'TYPOS_ERP_WC_LOG_OPT', 'typos_erp_wc_logs' );

require_once TYPOS_ERP_WC_DIR . 'includes/class-typos-logger.php';
require_once TYPOS_ERP_WC_DIR . 'includes/class-typos-api.php';
require_once TYPOS_ERP_WC_DIR . 'includes/class-typos-sync.php';
require_once TYPOS_ERP_WC_DIR . 'includes/class-typos-webhook.php';
require_once TYPOS_ERP_WC_DIR . 'includes/class-typos-admin.php';
require_once TYPOS_ERP_WC_DIR . 'includes/class-typos-stock-guard.php';

register_activation_hook( __FILE__, function () {
    if ( false === get_option( TYPOS_ERP_WC_OPTION ) ) {
        add_option( TYPOS_ERP_WC_OPTION, array(
            'api_key'       => '',
            'environment'   => 'live',
            'base_url'      => 'https://ietaxjtvtrfxtrkjvcso.supabase.co/functions/v1/public-api',
            'auto_sync'     => 'no',
            'push_stock'    => 'yes',
            'allow_backorders' => 'no',
            'webhook_secret'=> wp_generate_password( 32, false, false ),
        ) );
    }
});

add_action( 'plugins_loaded', function () {
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>Typos! ERP — WooCommerce</strong>: requer o plugin WooCommerce ativo.</p></div>';
        });
        return;
    }
    Typos_ERP_WC_Admin::instance();
    Typos_ERP_WC_Webhook::instance();
    Typos_ERP_WC_Sync::instance();
    Typos_ERP_WC_Stock_Guard::instance();
});
