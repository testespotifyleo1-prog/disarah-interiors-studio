=== Typos! ERP — WooCommerce ===
Contributors: typoserp
Tags: woocommerce, erp, estoque, integração, typos
Requires at least: 5.8
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.8.0
License: GPLv2 or later

Integra o Typos! ERP ao WooCommerce — sincroniza produtos, estoque e clientes via API REST v1.

== Descrição ==
* Painel administrativo com a identidade visual do Typos! ERP.
* Sincroniza produtos do ERP para o WooCommerce (pull manual e cron diário).
* Abate estoque no ERP automaticamente quando um pedido WooCommerce é pago/processado.
* Recebe webhooks de produto/estoque do Typos com verificação HMAC-SHA256.
* Suporte a ambientes live e test (sandbox).

== Instalação ==
1. Faça upload do arquivo .zip em **Plugins → Adicionar novo → Enviar plugin**.
2. Ative o plugin.
3. Acesse **Typos! ERP → Configurações** e cole sua chave de API.
4. Selecione a loja padrão e salve.

== Changelog ==
= 1.0.0 =
* Lançamento inicial.
