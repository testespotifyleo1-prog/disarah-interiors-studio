<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="wrap typos-wrap">
    <div class="typos-topbar">
        <div class="typos-brand">
            <span class="typos-logo">
                <span class="typos-logo-text">Typos</span><span class="typos-logo-bang">!</span><span class="typos-logo-badge">ERP</span>
            </span>
            <span class="typos-tagline">Gestão comercial · Integração WooCommerce</span>
        </div>
        <nav class="typos-tabs">
            <a class="<?php echo $_GET['page']==='typos-erp-wc'?'active':''; ?>" href="<?php echo esc_url( admin_url('admin.php?page=typos-erp-wc') ); ?>">Painel</a>
            <a class="<?php echo $_GET['page']==='typos-erp-wc-settings'?'active':''; ?>" href="<?php echo esc_url( admin_url('admin.php?page=typos-erp-wc-settings') ); ?>">Configurações</a>
            <a class="<?php echo $_GET['page']==='typos-erp-wc-logs'?'active':''; ?>" href="<?php echo esc_url( admin_url('admin.php?page=typos-erp-wc-logs') ); ?>">Logs</a>
            <a class="typos-tab-ext" target="_blank" rel="noopener" href="https://typoserp.com.br/docs/api">Documentação ↗</a>
        </nav>
    </div>
    <?php
    $notice = get_transient( 'typos_erp_notice' );
    if ( $notice ) {
        delete_transient( 'typos_erp_notice' );
        $cls = $notice[0] === 'error' ? 'typos-notice typos-notice-error' : 'typos-notice typos-notice-success';
        echo '<div class="' . esc_attr( $cls ) . '">' . esc_html( $notice[1] ) . '</div>';
    }
    ?>
    <h1 class="screen-reader-text"><?php echo esc_html( $title ); ?></h1>
