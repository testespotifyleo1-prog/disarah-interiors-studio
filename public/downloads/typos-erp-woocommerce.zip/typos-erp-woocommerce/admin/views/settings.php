<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<form method="post" action="options.php" class="typos-form">
    <?php settings_fields( 'typos_erp_wc_group' ); ?>
    <div class="typos-card">
        <h3>Conexão com a API</h3>
        <label>Chave de API
            <input type="text" name="<?php echo TYPOS_ERP_WC_OPTION; ?>[api_key]" value="<?php echo esc_attr( $s['api_key'] ); ?>" placeholder="tps_live_… ou tps_test_…" />
        </label>
        <label>Ambiente
            <select name="<?php echo TYPOS_ERP_WC_OPTION; ?>[environment]">
                <option value="live" <?php selected( $s['environment'], 'live' ); ?>>Produção (live)</option>
                <option value="test" <?php selected( $s['environment'], 'test' ); ?>>Sandbox (test)</option>
            </select>
        </label>
        <label>Base URL da API
            <input type="url" name="<?php echo TYPOS_ERP_WC_OPTION; ?>[base_url]" value="<?php echo esc_attr( $s['base_url'] ); ?>" />
            <small>Padrão da nuvem Typos! ERP — só altere se orientado.</small>
        </label>
    </div>

    <div class="typos-card">
        <h3>Sincronização</h3>
        <label>ID da loja padrão (UUID)
            <input type="text" name="<?php echo TYPOS_ERP_WC_OPTION; ?>[default_store_id]" value="<?php echo esc_attr( $s['default_store_id'] ?? '' ); ?>" placeholder="00000000-0000-0000-0000-000000000000" />
            <small>Loja do Typos que terá o estoque abatido a cada pedido WooCommerce.</small>
        </label>
        <label class="typos-check">
            <input type="checkbox" name="<?php echo TYPOS_ERP_WC_OPTION; ?>[push_stock]" value="yes" <?php checked( $s['push_stock'], 'yes' ); ?> />
            Abater estoque no Typos quando o pedido WooCommerce for processado/concluído.
        </label>
        <label class="typos-check">
            <input type="checkbox" name="<?php echo TYPOS_ERP_WC_OPTION; ?>[allow_backorders]" value="yes" <?php checked( $s['allow_backorders'] ?? 'no', 'yes' ); ?> />
            Permitir vendas mesmo quando o produto estiver sem estoque (backorder).
            <small>Quando desativado, produtos zerados ficam indisponíveis na loja. Aplica-se a cada atualização de estoque vinda do ERP e ao importar produtos.</small>
        </label>
        <label class="typos-check">
            <input type="checkbox" name="<?php echo TYPOS_ERP_WC_OPTION; ?>[auto_sync]" value="yes" <?php checked( $s['auto_sync'], 'yes' ); ?> />
            Executar pull diário de produtos automaticamente.
        </label>
    </div>

    <div class="typos-card">
        <h3>Webhook (entrada)</h3>
        <p>Endpoint exposto por este site para receber eventos do Typos:</p>
        <code class="typos-code"><?php echo esc_html( rest_url( 'typos-erp/v1/webhook' ) ); ?></code>
        <p>Secret atual:</p>
        <code class="typos-code"><?php echo esc_html( $s['webhook_secret'] ); ?></code>
        <p><small>Configure no Typos: <em>Desenvolvedores → Webhooks</em>. As mensagens são assinadas com HMAC-SHA256 no header <code>X-Typos-Signature</code>.</small></p>
    </div>

    <p><button class="typos-btn primary">Salvar alterações</button></p>
</form>
