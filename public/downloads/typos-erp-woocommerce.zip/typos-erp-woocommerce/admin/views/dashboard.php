<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="typos-grid">
    <div class="typos-card typos-card-hero">
        <h2>Bem-vindo ao Typos! ERP para WooCommerce</h2>
        <p>Sincronize produtos, estoque e clientes entre o seu ERP e a sua loja WooCommerce em poucos minutos.</p>
        <div class="typos-status">
            <span class="typos-dot <?php echo $configured ? 'ok' : 'off'; ?>"></span>
            <?php echo $configured ? 'Plugin configurado · ambiente <strong>' . esc_html( $s['environment'] ) . '</strong>' : 'Configure sua chave de API para começar.'; ?>
        </div>
        <div class="typos-actions">
            <a class="typos-btn primary" href="<?php echo esc_url( admin_url('admin.php?page=typos-erp-wc-settings') ); ?>">Abrir configurações</a>
            <?php if ( $configured ) : ?>
                <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" style="display:inline">
                    <?php wp_nonce_field( 'typos_erp_test' ); ?>
                    <input type="hidden" name="action" value="typos_erp_test">
                    <button class="typos-btn ghost">Testar conexão</button>
                </form>
                <button type="button" id="typos-pull-btn" class="typos-btn ghost">Sincronizar produtos agora</button>
                <label style="margin-left:8px;font-size:12px;color:#555;">
                    <input type="checkbox" id="typos-pull-images"> baixar imagens (mais lento)
                </label>
            <?php endif; ?>
        </div>

        <?php if ( $configured ) : ?>
        <div id="typos-pull-progress" class="typos-progress" style="display:none;margin-top:16px;">
            <div class="typos-progress-bar"><div class="typos-progress-fill" style="width:0%"></div></div>
            <div class="typos-progress-meta">
                <span id="typos-pull-status">Iniciando…</span>
                <span id="typos-pull-counts"></span>
            </div>
            <div id="typos-pull-error" style="display:none;color:#b91c1c;margin-top:8px;font-size:13px;"></div>
        </div>
        <?php endif; ?>
    </div>

    <div class="typos-card">
        <h3>1. Gere uma chave de API</h3>
        <p>Acesse <em>Desenvolvedores → Chaves de API</em> no Typos! ERP e crie uma chave com os escopos necessários (<code>products:read</code>, <code>stock:write</code>, <code>customers:write</code>).</p>
    </div>
    <div class="typos-card">
        <h3>2. Configure este plugin</h3>
        <p>Cole a chave em <strong>Configurações</strong>, escolha o ambiente (live/test) e selecione a <em>loja padrão</em> que abaterá estoque dos pedidos.</p>
    </div>
    <div class="typos-card">
        <h3>3. (Opcional) Webhooks</h3>
        <p>Cadastre o webhook abaixo no Typos para receber atualizações em tempo real:</p>
        <code class="typos-code"><?php echo esc_html( rest_url( 'typos-erp/v1/webhook' ) ); ?></code>
        <p style="margin-top:8px"><strong>Secret:</strong> <code class="typos-code"><?php echo esc_html( $s['webhook_secret'] ); ?></code></p>
    </div>
</div>
