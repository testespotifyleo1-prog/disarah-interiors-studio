<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="typos-card">
    <div style="display:flex;justify-content:space-between;align-items:center">
        <h3 style="margin:0">Eventos recentes (últimos 200)</h3>
        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
            <?php wp_nonce_field( 'typos_erp_clear_logs' ); ?>
            <input type="hidden" name="action" value="typos_erp_clear_logs">
            <button class="typos-btn ghost">Limpar logs</button>
        </form>
    </div>
    <table class="typos-table">
        <thead><tr><th>Quando</th><th>Nível</th><th>Mensagem</th></tr></thead>
        <tbody>
        <?php if ( empty( $logs ) ) : ?>
            <tr><td colspan="3"><em>Sem registros ainda.</em></td></tr>
        <?php else : foreach ( $logs as $l ) : ?>
            <tr>
                <td><?php echo esc_html( $l['time'] ); ?></td>
                <td><span class="typos-pill typos-pill-<?php echo esc_attr( $l['level'] ); ?>"><?php echo esc_html( $l['level'] ); ?></span></td>
                <td><?php echo esc_html( $l['message'] ); ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>
