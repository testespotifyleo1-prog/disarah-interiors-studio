(function($){
    $(function(){
        $('.typos-code').on('click', function(){
            const t = $(this).text();
            navigator.clipboard && navigator.clipboard.writeText(t);
            const o = $(this).css('background-color');
            $(this).css('background-color', '#16a34a');
            setTimeout(()=>$(this).css('background-color', o), 400);
        });

        const $btn      = $('#typos-pull-btn');
        const $progress = $('#typos-pull-progress');
        const $fill     = $('.typos-progress-fill');
        const $status   = $('#typos-pull-status');
        const $counts   = $('#typos-pull-counts');
        const $error    = $('#typos-pull-error');
        const $images   = $('#typos-pull-images');

        if (!$btn.length || typeof TyposERP === 'undefined') return;

        let running = false;

        async function pullPage(page, per_page, with_images){
            return $.ajax({
                url: TyposERP.ajaxUrl,
                method: 'POST',
                dataType: 'json',
                timeout: 90000,
                data: {
                    action: 'typos_erp_pull_page',
                    nonce: TyposERP.nonce,
                    page: page,
                    per_page: per_page,
                    with_images: with_images ? 1 : 0
                }
            });
        }

        $btn.on('click', async function(){
            if (running) return;
            running = true;
            $btn.prop('disabled', true).text('Sincronizando…');
            $progress.show();
            $error.hide().text('');
            $fill.css('width', '0%');
            $status.text('Iniciando…');
            $counts.text('');

            const per_page    = 20;
            const with_images = $images.is(':checked');
            let page          = 1;
            let totalCreated  = 0;
            let totalUpdated  = 0;
            let totalPages    = null;
            let consecutiveErrors = 0;

            while (true) {
                let res;
                try {
                    res = await pullPage(page, per_page, with_images);
                } catch (xhr) {
                    consecutiveErrors++;
                    if (consecutiveErrors >= 3) {
                        const msg = (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message)
                            || (xhr && xhr.statusText) || 'Erro desconhecido';
                        $error.show().text('Falha na página ' + page + ': ' + msg + ' — pare e tente novamente daqui a alguns minutos.');
                        break;
                    }
                    $status.text('Página ' + page + ' falhou, tentando novamente…');
                    await new Promise(r => setTimeout(r, 3000 * consecutiveErrors));
                    continue;
                }

                consecutiveErrors = 0;
                if (!res || !res.success) {
                    const msg = (res && res.data && res.data.message) || 'Resposta inválida';
                    $error.show().text('Erro: ' + msg);
                    break;
                }

                const d = res.data;
                totalCreated += d.created || 0;
                totalUpdated += d.updated || 0;
                if (totalPages == null && d.total_pages) totalPages = d.total_pages;

                const pct = totalPages ? Math.min(100, Math.round((page / totalPages) * 100)) : 0;
                $fill.css('width', pct + '%');
                $status.text('Página ' + page + (totalPages ? ' de ' + totalPages : '') + (d.total ? ' · ' + d.total + ' produtos' : ''));
                $counts.text(totalCreated + ' criados · ' + totalUpdated + ' atualizados');

                if (!d.has_more) {
                    $fill.css('width', '100%');
                    $status.text('Concluído!');
                    break;
                }
                page++;
                // pequeno respiro p/ não martelar API
                await new Promise(r => setTimeout(r, 250));
            }

            running = false;
            $btn.prop('disabled', false).text('Sincronizar produtos agora');
        });
    });
})(jQuery);
